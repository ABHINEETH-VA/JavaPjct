package test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/*
 * In this class based on the number of cmd args, those many files will be read and objects are created as per the file contents
 */
public class ReadFile 
{
	/*function for getting each cmd argument and to make calls for reading its contents*/
	public void readFile(String[] cmdArgs) throws ClassNotFoundException, IOException
	{
		int length = 0;
		int timeUnit = 0;
		String tmp = "";
		String planetSys = "";
		length = cmdArgs.length;
		for(int y=0; y<length; y++)
		{
			if(cmdArgs[y].startsWith("--"))
			{
				//this block can be used to make any additional changes needed in alignment 
				tmp = cmdArgs[y].replaceAll("--", "");
				timeUnit = Integer.parseInt(tmp);
				System.out.println("Alignment : " + timeUnit);
			}
			else
			{
				planetSys =  cmdArgs[y];
				System.out.print(planetSys+" : ");
				readFile(planetSys);
			}
			System.out.println();
		}
	}
	
	/*
	 * function to read the contents in a file and to create objects based on its contents
	 * it makes calls to get the angle and get other factors which required for judge the position
	 * it will sort the final object array as well
	 */
	public void readFile(String fileName) throws IOException, ClassNotFoundException
	{
		String tmpName = "Input\\"+fileName+".txt";
		File f = new File(tmpName);
		String str;
		String readStr = "";
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader(f));
			while((str = br.readLine()) != null)
			{
				readStr = readStr + " " + str;
			}
		} 
		catch (FileNotFoundException e)
		{
			System.out.println("File Not Found...");
		}
		/*
		 * file is split to cut the first line (system)
		 */
		String [] elmnts = readStr.split("- ");
		int count = 0;
		/*
		 * below block is to make sure, each section has got name, theta, radius and period 
		 * values are present and get the countof it
		 */
		for(String s: elmnts)
		{
			if(s.startsWith("name") && s.contains("theta") && s.contains("radius") && s.contains("period"))
			{
				count = count + 1;
			}
		}
		Planet[] arr = new Planet[count];
		List<Planet> objList = new ArrayList<Planet>();
		
		/*
		 * below block is to get individual values like name, theta etc..
		 * and will be calling the constructor for object creation and the final out come is added to a list.
		 */
		for(int i=1; i<=count; i++)		
		{
			String[] objArr = elmnts[i].split(":");
			String nameIP = (objArr[1].split(" "))[1].trim();
			int thetaIP = Integer.parseInt((objArr[2].split(" "))[1].trim());
			int radiusIP = Integer.parseInt((objArr[3].split(" "))[1].trim());
			int periodIP = Integer.parseInt((objArr[4].split(" "))[1].trim());
			
			/*
			 * Planet class constructor will be called from this point and all sort of operations related to the class 
			 * is done from inside the planet class
			 */
			arr[i-1] = new Planet(nameIP, thetaIP,radiusIP, periodIP);
			objList.add(arr[i-1]);
		}
		
		//Object sorting is done via comparator
		objList.sort(Comparator.comparing(a -> a.angle));
		Iterator<Planet> itr = objList.iterator();		
		while(itr.hasNext())
		{
			itr.next().getAllValues();
		}		
	}

}
