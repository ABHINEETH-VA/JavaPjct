package test;

import java.io.IOException;

/*
 * This is the starting point of the pgm and it will accept the command line arguments.
 * based on the cmd args it will create those many number of Planets based on the correct input provided in the source file (foo, bar, etc...)
 * the cmd line will have the source file name as well as an optional alignment factor
 * the source files are kept undetr input folder which is in the project root
 */

public class SolarSystem 
{
	public static void main(String[] args) throws IOException, ClassNotFoundException 
	{
		System.out.println("Planet System");
		System.out.println("-----------------------------------------------------");
		
		//ReadFile class object is created to play with command line args
		ReadFile rf = new ReadFile();
		rf.readFile(args);
	}
}
