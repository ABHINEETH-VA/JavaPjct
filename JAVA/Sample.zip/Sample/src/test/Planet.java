package test;

import java.text.SimpleDateFormat;
import java.util.Calendar;


/*
 * this is the class used for Planet creation and alignment angle calculation 
 */
public class Planet 
{
	String name;
	int theta;
	int radius;
	int period;
	int angle;
	double retAnk;
	
	/*
	 * constructor if no args are present
	 */
	public Planet()
	{
		name = "NA";
		theta = 0;
		radius = 0;
		period = 0;
		angle = 0;
	}
	
	/*
	 * Function for getting the Planet value printing
	 */
	public void getAllValues()
	{
		System.out.print(name+", ");
		//System.out.println("Name : " + name);
		//System.out.println("Theta : " + theta);
		//System.out.println("Radius : " + radius);
		//System.out.println("Period : " + period);
		//System.out.println("Angle : " + angle);
		//System.out.println("-----------------------------------------------------");
	}
	
	/*
	 * constructor if values are supplied
	 * from here angle will also be calculated which is used to decide its position
	 */
	public Planet(String nam, int thetaAngle, int rad, int pd)
	{
		this.name = nam;
		this.theta = thetaAngle;
		this.radius = rad;
		this.period = pd;
		this.angle = (int) getAngle(thetaAngle, pd);
		//System.out.println("Angle :  " + this.angle);
	}
    
	/* getters and setters
	 * 
	 */
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public int getTheta() 
	{
		return theta;
	}

	public void setTheta(int theta) 
	{
		this.theta = theta;
	}

	public int getRadius() 
	{
		return radius;
	}

	public void setRadius(int radius) 
	{
		this.radius = radius;
	}

	public int getPeriod() 
	{
		return period;
	}

	public void setPeriod(int period) 
	{
		this.period = period;
	}
	
	/*
	 * function to calculate angle based on the equation provided
	 */
	private double getAngle(int tAng, int pd)
	{
		double ang = 0;
		double pi = 3.14;
		double tmpVal = 0;
		double retAng = 0;
		tmpVal = getTime();
		
		ang = tAng + (tmpVal/pd)*2*pi;
		//System.out.println("Angle Value after Period Division : " + (tmpVal/pd));
		retAng = angleSet(ang);
		return retAng;
	}
	
	/*
	 * Function for getting the values in minutes
	 * current time is used for this and only hour and minutes are taken into consideration for this
	 * used some imports here
	 */
	private int getTime()
	{
		Calendar cal = Calendar.getInstance();
		int calcTime = 0;
	    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");   
		String timeStamp = sdf.format(cal.getTime());
		String [] timeComp = timeStamp.split(":");
		calcTime  = (Integer.parseInt(timeComp[0]))*60 + Integer.parseInt(timeComp[1]);
		//System.out.println("TimeStampValue : " + calcTime);
		return calcTime;
	}
	
	/*
	 * function to get the correct angle
	 * its a recursive call
	 */
	private double angleSet(double ank)
	{
		if(ank>360)
		{
			ank = ank - 360;
			angleSet(ank);
		}
		else
		{
			retAnk = ank;
		}
		return retAnk;
	}
}
