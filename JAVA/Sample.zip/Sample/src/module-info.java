module Sample {
}