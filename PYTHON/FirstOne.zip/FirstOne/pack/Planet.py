'''
Created on 02-May-2022

@author: Abhineeth
Planet class and its related operations are done here
datetime library has been imported
'''
from _datetime import datetime

class Planet:
    
    theta = 0;
    radius = 0;
    period = 0;
    name = "";
    angle = 0;
    fin = 0;
    
    #function for object Initialization
    def __init__(self,nam,thet,rad,pd):
        self.name = nam;
        self.theta = thet;
        self.radius = rad;
        self.period = pd;
        self.angle = self.angleCalc(thet,pd);
        
    # function for detailed display    
    def display(self):
        print("-------------------------------------");
        print("Planet : " + self.name);
        print("Theta is : " + str(self.theta));
        print("Radius is : " + str(self.radius));
        print("Period is : " + str(self.period));
        print("Angle is : " + str(self.angle));
        print(self.name + ", ")
        print("-------------------------------------");
    
    #function for dsplay as per req.   
    def displayNew(self,counter):
        return self.name;
    
    #function for calculating the angle    
    def performOperation(self):
        self.angleCalc(self.theta,self.period);
    
    #Angle calculation     
    def angleCalc(self,T,P):
        #print("Angle calculation");
        timeFactor = self.timeCalc();
        calAng = T + (timeFactor/P) * 2 * 3.14 ;
        dupAng = calAng;
        #print("Calculated Angle : " + str(calAng));
        finalAng = self.recAngCalc(calAng);
        #print("Final Angle : " + str(finalAng));
        return finalAng;
    
    #time calculation in HH:MM format
    def timeCalc(self):
        #print("Time calculation");
        now = datetime.now();
        current_time = now.strftime("%H:%M");
        #print ("Time is : " + current_time);
        timeElmnts = current_time.split(":");
        timeSum = int(timeElmnts[0]) * 60 + int(timeElmnts[1]);
        #print("final time : " + str(timeSum));
        return timeSum;
    
    #function for calculating the angle in recursive way 
    def recAngCalc(self,Ang):
        final = Ang;
        Planet.fin = Ang;
        if(Ang > 360):
            tmp = 0;
            tmp = Ang - 360;
            Ang = tmp;
            if(Ang > 360):
                self.recAngCalc(Ang)
            else:
                final = Ang;
                Planet.fin = Ang;            

        return int(Planet.fin);