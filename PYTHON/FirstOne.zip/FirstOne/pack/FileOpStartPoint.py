'''
Created on 04-May-2022

@author: Abhineeth
SYS,OS and Test1 class has been imported for operation purpose
'''
import sys
import os
from pack import Planet

class start():
    #function for reading file and then to display items
    def readFile(self,filePath):
        list = [];
        dir = os.path.dirname(__file__);
        fileName = dir + "\\" + filePath;
        #print(fileName)
        with open(fileName) as f:
            lines = f.read();
        f.close();   
        
        #this will give you how many objects we need to create 
        sp1 = lines.split("- ");
        objSize = len(sp1) - 1;
        
        #this will be used to create objects based on the input file
        for x in range(objSize):
            # to get one block of obj.
            wordblck = sp1[x+1].split(": ");
            wrdBlkSize =len(wordblck);

            #to get each element
            for y in range(wrdBlkSize-1):
                elmnts = wordblck[y+1].split();
                elmntsSize = len(elmnts);

                if(elmntsSize == 1):
                    PERIOD = elmnts[0];
                else:
                    if "planet" in elmnts[0]:
                        PLANET = elmnts[0];
                    elif "radius" in elmnts[1]:
                        THETA = elmnts[0];
                    elif "period" in elmnts[1]:
                        RADIUS = elmnts[0];          
            list.append(Planet.Planet(PLANET,int(THETA),int(RADIUS),int(PERIOD)));
            
        #sort objects based on angle
        list.sort(key=lambda z: z.angle);
        
        #calling Display
        lenList = len(list);
        finalStr = ""
        for obj in list:            
            dispStr = obj.displayNew(lenList);
            if (finalStr == ""):
                finalStr = dispStr;
            else:
                finalStr = finalStr + ", "+dispStr
        print((filePath.split("."))[0] + " : " + finalStr)
        finalStr = ""   
        
#Entry point to the program and need to be invoked via CMD
n = len(sys.argv);

#created class object and then called the start function to read file contents and will iterate as per input
st = start();
for i in range(n-1):
    st.readFile(sys.argv[i+1]);

